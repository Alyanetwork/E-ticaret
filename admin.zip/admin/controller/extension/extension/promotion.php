<?php
class ControllerExtensionExtensionPromotion extends Controller {
    public function index() {
        $html = '';
        $html .= '';
        $html .= '';
 
        return $html;
    }
}