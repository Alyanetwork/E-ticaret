<?php
// Heading
$_['heading_title']	 = 'OpenBay Pro';
