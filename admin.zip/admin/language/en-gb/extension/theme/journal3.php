<?php
// Heading
$_['heading_title'] = 'Journal Theme' . (defined('JOURNAL3_ENV') && JOURNAL3_ENV === 'development' ? ' Opencart 3' : '');
