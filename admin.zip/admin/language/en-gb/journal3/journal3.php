<?php
$_['error_input_not_found'] = '%s: Parameter %s is not found!';
