<?php 

$_['heading_title']     =  'Categorie totali';
$_['text_extension']     =  'estensioni';
$_['text_success']     =  'Successo: hai modificato il modulo categorie dashboard!';
$_['text_edit']     =  'Modifica Dashboard Categorie';
$_['text_view']     =  'Visualizza altro ...';
$_['entry_status']     =  'Stato Categoria';
$_['entry_sort_order']     =  'Ordina';
$_['entry_width']     =  'Larghezza';
$_['error_permission']     =  'Avviso: Non hai il permesso di modificare il modulo categoria dashboard!';
