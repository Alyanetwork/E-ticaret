<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_footer']  = 'Altyapı: <a href="http://www.edonusumofisi.com">E-Dönüşüm Ofisi</a> Türkçe Çeviri: <a href="http://edonusumofisi.com" title="Alya E-Ticaret ve Bilgi Teknolojileri">E-Dönüşüm</a> &copy; 2015 - ' . date('Y') . ' Tüm Hakları Saklıdır.';
$_['text_version'] = 'Sürüm %s';