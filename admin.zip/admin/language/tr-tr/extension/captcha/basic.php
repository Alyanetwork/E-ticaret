<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Basit Doğrulama';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Basit Doğrulama başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Basit Doğrulama Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Basit Doğrulamayı düzenleme iznine sahip değilsiniz!';
