<?php
// Heading
$_['heading_title']    = 'Dünya Haritası';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Dünya haritası gösterge paneli başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Dünya Haritasını Düzenle';
$_['text_order']       = 'Siparişler';
$_['text_sale']        = 'Satışlar';

// Entry
$_['entry_width']      = 'Genişlik';
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Dünya haritası gösterge panelini düzenleme iznine sahip değilsiniz!';