<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Pazarlama';

// Text
$_['text_success']     = 'Başarılı: Pazarlama güncellendi!';
$_['text_list']        = 'Pazarlama Listesi';

// Column
$_['column_name']      = 'Pazarlama Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Pazarlamaları değiştirme iznine sahip değilsiniz!';