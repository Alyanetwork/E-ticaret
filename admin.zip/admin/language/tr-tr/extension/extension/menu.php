<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Menü';

// Text
$_['text_success']     = 'Başarılı: Menü güncellendi!';
$_['text_list']        = 'Menü Listesi';

// Column
$_['column_name']      = 'Menü Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Menüleri değiştirme iznine sahip değilsiniz!';