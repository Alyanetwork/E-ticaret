<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Raporlar';

// Text
$_['text_success']     = 'Başarılı: Raporlar güncellendi!';
$_['text_list']        = 'Raporlar Listesi';

// Column
$_['column_name']      = 'Raporlar Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Raporları değiştirme iznine sahip değilsiniz!';