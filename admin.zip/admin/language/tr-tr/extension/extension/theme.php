<?php
// Heading
$_['heading_title']    = 'Temalar';

// Text
$_['text_success']     = 'Başarılı: Temalar başarılı bir şekilde değiştirildi!';
$_['text_list']        = 'Tema Listesi';

// Column
$_['column_name']      = 'Tema Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Temaları düzenleme iznine sahip değilsiniz!';