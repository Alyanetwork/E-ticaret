<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Kategoriler';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Kategori modülü güncellendi!';
$_['text_edit']        = 'Kategori Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Kategori modülünü değiştirme iznine sahip değilsiniz!';