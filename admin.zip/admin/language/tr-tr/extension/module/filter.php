<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Filtreler';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Filtreler modülü güncellendi!';
$_['text_edit']        = 'Filtre Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Filtreler modülünü değiştirme iznine sahip değilsiniz!';