<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Bilgiler';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Bilgiler modülü güncellendi!';
$_['text_edit']        = 'Bilgiler Modülünü Düzenle';

// Entry
$_['entry_status']     = 'Durumu';

// Error
$_['error_permission'] = 'Uyarı: Bilgiler modülünü değiştirme iznine sahip değilsiniz!';