<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Sabit Kargo Fiyatı';

// Text
$_['text_extension']   = 'Eklentiler';
$_['text_success']     = 'Başarılı: Sabit Kargo Fiyatı başarılı bir şekilde değiştirildi!';
$_['text_edit']        = 'Sabit Kargo Fiyatını Düzenle';

// Entry
$_['entry_cost']       = 'Fiyatı';
$_['entry_tax_class']  = 'Vergi Oranı';
$_['entry_geo_zone']   = 'Bölge';
$_['entry_status']     = 'Durumu';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Uyarı: Sabit kargo fiyatı düzenleme iznine sahip değilsiniz!';