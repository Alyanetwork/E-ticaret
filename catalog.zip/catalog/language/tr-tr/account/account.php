<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']       = 'Hesabım';

// Text
$_['text_account']        = 'Hesabım';
$_['text_my_account']     = 'Hesabım';
$_['text_my_orders']      = 'Siparişlerim';
$_['text_my_affiliate']   = 'Ortaklık Hesabım';
$_['text_my_newsletter']  = 'Bülten Aboneliği';
$_['text_edit']           = 'Hesap Bilgilerimi Düzenle';
$_['text_password']       = 'Parola Değiştir';
$_['text_address']        = 'Adres Defterlerini Düzenle';
$_['text_credit_card']    = 'Kayıtlı Kredi Kartları';
$_['text_wishlist']       = 'Alışveriş Listemi Düzenle';
$_['text_order']          = 'Siparişlerim';
$_['text_download']       = 'Dosyalarım';
$_['text_reward']         = 'Puanlarım';
$_['text_return']         = 'İade Taleplerim';
$_['text_transaction']    = 'Bakiye İşlemlerim';
$_['text_newsletter']     = 'Bültene Abone Ol / Kaldır.';
$_['text_recurring']      = 'Otomatik Ödemeler';
$_['text_transactions']   = 'İşlemler';
$_['text_affiliate_add']  = 'Ortaklık hesabı için kayıt ol';
$_['text_affiliate_edit'] = 'Ortaklık bilgilerini düzenle';
$_['text_tracking']       = 'Özel Ortaklık Takip Kodu';