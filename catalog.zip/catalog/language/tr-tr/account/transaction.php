<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']      = 'Bakiye İşlemlerim';

// Column
$_['column_date_added']  = 'Ekleme Tarihi';
$_['column_description'] = 'Açıklama';
$_['column_amount']      = 'Tutar (%s)';

// Text
$_['text_account']       = 'Hesabım';
$_['text_transaction']   = 'Bakiye İşlemlerim';
$_['text_total']         = 'Geçerli bakiyeniz:';
$_['text_empty']         = 'Herhangi bir işleminiz yok!';