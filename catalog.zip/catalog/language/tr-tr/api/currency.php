<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_success']     = 'Başarılı: Para birimi değiştirildi!';

// Error
$_['error_permission'] = 'Uyarı: API erişim iznine sahip değilsiniz!';
$_['error_currency']   = 'Uyarı: Para birim kodu geçersiz!';