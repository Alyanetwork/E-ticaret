<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_items']     = '%s ürün - %s';
$_['text_empty']     = 'Alışveriş sepetiniz boş!';
$_['text_cart']      = 'Sepetime Git';
$_['text_checkout']  = 'Kasaya Git';
$_['text_recurring'] = 'Ödeme Profili';