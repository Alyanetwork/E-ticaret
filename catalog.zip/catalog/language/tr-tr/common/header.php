<?php
/* Turkceye Ceviren E-Dönüşüm Ofisi - http://edonusumofisi.com */

// Text
$_['text_home']          = 'Anasayfa';
$_['text_wishlist']      = 'A. Listem (%s)';
$_['text_shopping_cart'] = 'Sepetim';
$_['text_category']      = 'Kategoriler';
$_['text_account']       = 'Hesabım';
$_['text_register']      = 'Kayıt Ol';
$_['text_login']         = 'Oturum Aç';
$_['text_order']         = 'Sipariş Geçmişi';
$_['text_transaction']   = 'Bakiye İşlemlerim';
$_['text_download']      = 'Dosyalarım';
$_['text_logout']        = 'Çıkış Yap';
$_['text_checkout']      = 'Kasaya Git';
$_['text_search']        = 'Ara';
$_['text_all']           = 'Tümü Göster';