<?php
/* Turkceye Ceviren E-Dönüşüm Ofisi - http://edonusumofisi.com */

// Text
$_['text_language'] = 'Dil';