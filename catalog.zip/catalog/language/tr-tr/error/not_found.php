<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title'] = 'Aradığınız Sayfa Bulunamadı!';

// Text
$_['text_error']    = 'Aradığınız Sayfa Bulunamadı.';