<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_cron_email_message'] = '<p>Bu, Google Shopping uzantınız tarafından gerçekleştirilen en son CRON görevinin otomatik bir rapordur.</p><p>%s</p>';
$_['text_cron_email_subject'] = 'CRONJOB Raporu - Google Shopping on OpenCart';
$_['text_per_day']            = '$%s / gün';