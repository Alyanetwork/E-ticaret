<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_captcha']  = 'Doğrulama Kodu';

// Entry
$_['entry_captcha'] = 'Doğrulama kodunu giriniz';

// Error
$_['error_captcha'] = 'Doğrulama kodu yanlış!';