<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title'] = 'Sizin için Seçtiklerimiz';

// Text
$_['text_tax']      = 'Vergiler Hariç:';