<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title'] = 'Bilgiler';

// Text
$_['text_contact']  = 'İletişim';
$_['text_sitemap']  = 'Site Haritası';