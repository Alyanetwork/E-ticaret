<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title'] = 'Yeni Ürünler';

// Text
$_['text_tax']      = 'Vergiler Hariç:';