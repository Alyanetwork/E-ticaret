<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_title']       = 'Çek / Havale';
$_['text_instruction'] = 'Çek / Havale Talimatları';
$_['text_payable']     = 'Ödenecek Kişi:';
$_['text_address']     = 'Adres:';
$_['text_payment']     = 'Siparişinizi verdikten sonraki 5 iş günü içinde çeki göndermediniz taktirde siparişiniz iptal olur.';