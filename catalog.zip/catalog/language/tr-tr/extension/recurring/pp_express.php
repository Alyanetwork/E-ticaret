<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_title']          = 'PayPal Express Checkout';
$_['text_canceled']       = 'Başarılı: Otomatik ödeme başarılı bir şekilde iptal edildi!';

// Button
$_['button_cancel']       = 'Otomatik Ödemeyi İptal Et';

// Error
$_['error_not_cancelled'] = 'Hata: %s';
$_['error_not_found']     = 'Otomatik ödeme profili iptal edilemedi';