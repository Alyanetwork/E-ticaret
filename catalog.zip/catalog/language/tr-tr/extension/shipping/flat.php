<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_title']       = 'Sabit Fiyatlı Kargo';
$_['text_description'] = 'Sabit Fiyatlı Kargo';