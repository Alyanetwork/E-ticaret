<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_title']       = 'Mağazadan Teslim Al';
$_['text_description'] = 'Mağazadan Teslim Al';