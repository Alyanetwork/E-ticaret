<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_low_order_fee'] = 'Düşük Sipariş Fiyatı';