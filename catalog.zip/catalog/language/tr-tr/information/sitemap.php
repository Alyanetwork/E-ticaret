<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']    = 'Site Haritası';

// Text
$_['text_special']     = 'Kampanyalar';
$_['text_account']     = 'Hesabım';
$_['text_edit']        = 'Hesap Bilgileri';
$_['text_password']    = 'Parola Değiştir';
$_['text_address']     = 'Adreslerim';
$_['text_history']     = 'Siparişlerim';
$_['text_download']    = 'Dosyalarım';
$_['text_cart']        = 'Sepetim';
$_['text_checkout']    = 'Kasaya Git';
$_['text_search']      = 'Arama';
$_['text_information'] = 'Bilgiler';
$_['text_contact']     = 'İletişim';