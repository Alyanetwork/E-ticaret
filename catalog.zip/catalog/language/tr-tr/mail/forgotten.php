<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_subject']  = '%s - Parola sıfırlama isteği';
$_['text_greeting'] = '%s müşteri hesabınız için parola sıfırlama talebinde bulundunuz.';
$_['text_change']   = 'Parolanızı sıfırlamak için aşağıdaki bağlantıya tıklayın:';
$_['text_ip']       = 'Parola sıfırlama isteğiniz bu IP adresinden yapıldı:';