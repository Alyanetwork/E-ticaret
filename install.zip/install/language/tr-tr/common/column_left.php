<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_license']       = 'Lisans';
$_['text_installation']  = 'Ön Yükleme';
$_['text_configuration'] = 'Yapılandırma';
$_['text_upgrade']       = 'Yükseltme';
$_['text_finished']      = 'Tamamlandı';
$_['text_language']      = 'Dil';