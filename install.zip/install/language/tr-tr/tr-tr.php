<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Buttons
$_['button_continue'] = 'Devam Et';
$_['button_back']     = 'Geri';

// Error
$_['error_exception'] = 'Hata Kodu(%s): %s in %s on line %s';