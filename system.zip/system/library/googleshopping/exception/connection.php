<?php

namespace googleshopping\Exception;

class Connection extends \RuntimeException {
}
